#!/usr/bin/env python3
"""
Asset web service test
"""
